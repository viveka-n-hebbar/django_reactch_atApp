import React, { useEffect, useState, useRef } from "react";
import UserList from "./components/userlist";
import ChatBox from "./components/ChatBox";

function App() {
  const [messages, setMessages] = useState([]);
  const [content, setContent] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [users, setUsers] = useState([
    { id: 1, username: "Alice", unread: 0 },
    { id: 2, username: "Bob", unread: 2 },
    { id: 3, username: "Charlie", unread: 1 },
  ]);
  const [typingUser, setTypingUser] = useState(null);  // State for typing indicator
  const typingTimeout = useRef(null);  // Ref for timeout to hide typing indicator

  const socketRef = useRef(null);
  const roomName = selectedUser ? selectedUser.username.toLowerCase() : "general";

  useEffect(() => {
    socketRef.current = new WebSocket(`ws://127.0.0.1:8000/ws/chat/${roomName}/`);

    socketRef.current.onmessage = (e) => {
      const data = JSON.parse(e.data);

      if (data.type === "typing") {
        setTypingUser(data.username);

        // Clear old timeout and set new timeout for 2 seconds
        if (typingTimeout.current) clearTimeout(typingTimeout.current);
        typingTimeout.current = setTimeout(() => {
          setTypingUser(null);
        }, 2000);
      } else {
        setMessages((prev) => [...prev, data]);
      }
    };

    socketRef.current.onopen = () => console.log("WebSocket connected.");
    socketRef.current.onclose = () => console.log("WebSocket disconnected.");

    return () => socketRef.current && socketRef.current.close();
  }, [roomName]);

  const sendMessage = () => {
    if (socketRef.current && content.trim()) {
      socketRef.current.send(
        JSON.stringify({
          message: content,
          username: "User1", // Replace with auth user if needed
        })
      );
      setContent("");
    }
  };

  const handleUserClick = (user) => {
    setSelectedUser(user);
    setMessages([]); // Clear messages on switching user
  };

  // Emit typing signal when the user types
  const handleInputChange = (e) => {
    setContent(e.target.value);

    if (socketRef.current) {
      socketRef.current.send(
        JSON.stringify({
          type: "typing",
          username: "User1", // Replace with actual username
        })
      );
    }
  };

  return (
    <div style={{ display: "flex", height: "100vh", padding: 20 }}>
      <div style={{ width: 200, borderRight: "1px solid #ccc", paddingRight: 10 }}>
        <UserList users={users} selectedUser={selectedUser} onUserClick={handleUserClick} />
      </div>
      <div style={{ flex: 1, paddingLeft: 20 }}>
        <h1>Chat with {selectedUser ? selectedUser.username : "Everyone"}</h1>
        <ChatBox
          messages={messages}
          content={content}
          setContent={setContent}
          onSend={sendMessage}
          onInputChange={handleInputChange}
        />
        {/* Typing indicator */}
        {typingUser && <p><i>{typingUser} is typing...</i></p>}
      </div>
    </div>
  );
}

export default App;
