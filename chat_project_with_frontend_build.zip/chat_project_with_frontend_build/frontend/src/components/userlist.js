import React from "react";

const UserList = ({ users, selectedUser, onUserClick }) => {
  return (
    <div>
      <h3>Users</h3>
      {users.map((user) => (
        <div
          key={user.id}
          style={{
            padding: "8px",
            marginBottom: "4px",
            cursor: "pointer",
            backgroundColor: selectedUser?.id === user.id ? "#e0e0e0" : "transparent",
            fontWeight: selectedUser?.id === user.id ? "bold" : "normal",
          }}
          onClick={() => onUserClick(user)}
        >
          {user.username}
          {user.unread > 0 && <span style={{ color: "red" }}> ({user.unread})</span>}
        </div>
      ))}
    </div>
  );
};

export default UserList;
