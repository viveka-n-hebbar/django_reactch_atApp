import React, { useState } from 'react';
import './ChatBox.css';

const ChatBox = ({ messages, onSendMessage }) => {
  const [text, setText] = useState('');

  const send = () => {
    if (text.trim() === '') return;
    onSendMessage(text);
    setText('');
  };

  return (
    <div className="chat-box">
      <div className="messages">
        {messages.map((m, idx) => (
          <div key={idx} className={`message ${m.sender === 'Me' ? 'me' : 'other'}`}>
            <strong>{m.sender}:</strong> {m.text}
            <div className="read-status">{m.is_read ? '✓✓' : '✓'}</div>
          </div>
        ))}
      </div>
      <div className="input-area">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
          placeholder="Type a message..."
        />
        <button onClick={send}>Send</button>
      </div>
    </div>
  );
};

export default ChatBox;
