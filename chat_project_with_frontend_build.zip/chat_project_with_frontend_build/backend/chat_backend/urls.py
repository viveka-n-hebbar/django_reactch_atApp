
from django.contrib import admin
from django.views.generic import TemplateView
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('chat.urls')),  # Your API routes
    path('', TemplateView.as_view(template_name="index.html")),  # React frontend
]
