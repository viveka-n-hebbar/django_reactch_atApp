
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import ChatRoom, Message
from django.contrib.auth.models import User

class UserChatRooms(APIView):
    def get(self, request):
        rooms = ChatRoom.objects.filter(users=request.user)
        data = [{"id": room.id, "users": [user.username for user in room.users.all()]} for room in rooms]
        return Response(data)
