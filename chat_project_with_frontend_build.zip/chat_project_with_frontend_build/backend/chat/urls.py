
from django.urls import path
from .views import UserChatRooms

urlpatterns = [
    path("rooms/", UserChatRooms.as_view(), name="user-chat-rooms"),
]
